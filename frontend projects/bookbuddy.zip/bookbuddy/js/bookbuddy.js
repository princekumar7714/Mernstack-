// const OpenBtn = document.getElementById("search");
// const searchBody = document.getElementById("navsearch");
// const closebtn = document.getElementById("closebtn");

// const openMenu = () => {
//     console.log("Clicked Open search box");
//     searchBody.style.display = "block";
    
// }

// const closeMenu = () => {
//     console.log("Clicked Close search box");
//     searchBody.style.display = "none";
// }

// OpenBtn.addEventListener("click", openMenu);
// closebtn.addEventListener("click", closeMenu);



// Get elements
const openBtn = document.getElementById("search-btn");
const searchBody = document.getElementById("navsearch");
const closeBtn = document.getElementById("close-btn");

// Functions
const openMenu = () => {
    searchBody.style.display = "block";
}

const closeMenu = () => {
    searchBody.style.display = "none";
}

// Event listeners
openBtn.addEventListener("click", openMenu);
closeBtn.addEventListener("click", closeMenu);